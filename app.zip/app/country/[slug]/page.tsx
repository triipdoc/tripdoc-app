import { supabase } from "../../../lib/supabase";
import { isPublicProgramListVisible } from "../../../lib/opportunityPrograms";
import type { Metadata } from "next";
import Link from "next/link";
import ProgramImage from "../../components/ProgramImage";

type Program = {
  id: string;
  title: string;
  slug: string | null;
  country: string | null;
  funding_type: string | null;
  image_url: string | null;
  verification_status: string | null;
  publishing_status?: string | null;
  availability_status?: string | null;
  deadline?: string | null;
  deadline_mode?: string | null;
};

function formatCountryLabel(value: string) {
  return value
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const countryName = decodeURIComponent(slug);
  const label = formatCountryLabel(countryName);

  return {
    title: `Opportunities in ${label} | TripDoc`,
    description: `Explore verified scholarships, internships, fellowships, and research opportunities available in ${label} on TripDoc.`,
    openGraph: {
      title: `Opportunities in ${label} | TripDoc`,
      description: `Explore verified opportunities available in ${label} on TripDoc.`,
      url: `https://app.tripdoc.net/countries/${encodeURIComponent(countryName)}`,
      siteName: "TripDoc",
      type: "website",
    },
    twitter: {
      card: "summary_large_image",
      title: `Opportunities in ${label} | TripDoc`,
      description: `Explore verified opportunities available in ${label} on TripDoc.`,
    },
  };
}

export default async function CountryPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const countryName = decodeURIComponent(slug);
  const label = formatCountryLabel(countryName);

  const { data, error } = await supabase
    .from("program_public_view")
    .select("id,title,slug,country,funding_type,image_url,verification_status,publishing_status,availability_status,deadline,deadline_mode")
    .eq("publishing_status", "published")
    .eq("country", label)
    .order("created_at", { ascending: false });

  if (error) {
    return (
      <main style={{ maxWidth: 1000, margin: "0 auto", padding: 40 }}>
        <Link
          href="/"
          style={{
            display: "inline-block",
            marginBottom: 20,
            textDecoration: "none",
            color: "#0070f3",
            fontWeight: 600,
          }}
        >
          ← Back to home
        </Link>

        <h1 style={{ marginBottom: 12 }}>Something went wrong</h1>
        <p style={{ color: "#666" }}>Unable to load this country page right now.</p>
      </main>
    );
  }

  const programs = (data || []).filter(
    (p: Program) =>
      p.title && p.slug && p.title.trim() !== "" && isPublicProgramListVisible(p)
  ) as Program[];

  return (
    <main style={{ maxWidth: 1000, margin: "0 auto", padding: 40 }}>
      <Link
        href="/"
        style={{
          display: "inline-block",
          marginBottom: 20,
          textDecoration: "none",
          color: "#0070f3",
          fontWeight: 600,
        }}
      >
        ← Back to home
      </Link>

      <div style={{ marginBottom: 28 }}>
        <h1 style={{ marginBottom: 10 }}>Opportunities in {label}</h1>

        <p style={{ color: "#666", margin: 0 }}>
          Explore verified opportunities available in {label}.
        </p>
      </div>

      {programs.length === 0 ? (
        <div
          style={{
            border: "1px solid #ddd",
            borderRadius: 12,
            padding: 24,
            background: "#fafafa",
          }}
        >
          <h2 style={{ marginTop: 0, marginBottom: 8 }}>No opportunities yet</h2>
          <p style={{ margin: 0, color: "#666" }}>
            No verified opportunities were found for this country for now.
          </p>
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: 20,
          }}
        >
          {programs.map((p) => (
            <Link
              key={p.id}
              href={`/programs/${p.slug}`}
              style={{
                display: "block",
                border: "1px solid #ddd",
                padding: 20,
                borderRadius: 12,
                background: "#fafafa",
                textDecoration: "none",
                color: "inherit",
                boxShadow: "0 2px 6px rgba(0,0,0,0.04)",
                transition: "all 0.2s ease",
              }}
            >
              <ProgramImage
                src={p.image_url}
                alt={p.title}
                width={640}
                height={160}
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 360px"
                borderRadius={10}
                marginBottom={12}
              />

              <div
                style={{
                  fontSize: 20,
                  fontWeight: 600,
                  color: "black",
                  marginBottom: 10,
                  lineHeight: 1.4,
                }}
              >
                {p.title}
              </div>

              <div style={{ marginBottom: 10, color: "#444" }}>
                {p.country || "—"} • {p.funding_type || "—"}
              </div>

              <div>
                <span
                  style={{
                    display: "inline-block",
                    padding: "4px 10px",
                    borderRadius: 999,
                    fontSize: 12,
                    fontWeight: 700,
                    border: "1px solid #ddd",
                    background: "#eaffea",
                  }}
                >
                  {p.verification_status === "verified"
                    ? "Verified"
                    : p.verification_status === "conflicting_evidence"
                    ? "Conflicting evidence"
                    : "Needs review"}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
