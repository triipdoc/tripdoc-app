import { supabase } from "../../../lib/supabase";
import { isPublicProgramListVisible } from "../../../lib/opportunityPrograms";
import type { Metadata } from "next";
import Link from "next/link";
import ProgramImage from "../../components/ProgramImage";

type Program = {
  id: string;
  title: string;
  slug: string | null;
  country: string | null;
  type: string | null;
  funding_type: string | null;
  deadline: string | null;
  image_url: string | null;
  verification_status: string | null;
  publishing_status?: string | null;
  availability_status?: string | null;
  deadline_mode?: string | null;
  created_at?: string | null;
};

const SITE_URL = "https://app.tripdoc.net";

function formatCountryName(value: string) {
  return decodeURIComponent(value)
    .replace(/-/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ country: string }>;
}): Promise<Metadata> {
  const { country } = await params;
  const formattedCountry = formatCountryName(country);

  const title = `Opportunities in ${formattedCountry} | TripDoc`;
  const description = `Browse verified scholarships, internships, fellowships, and global opportunities in ${formattedCountry} on TripDoc.`;

  return {
    title,
    description,
    alternates: {
      canonical: `${SITE_URL}/countries/${country}`,
    },
    openGraph: {
      title,
      description,
      url: `${SITE_URL}/countries/${country}`,
      siteName: "TripDoc",
      type: "website",
    },
    twitter: {
      card: "summary",
      title,
      description,
    },
  };
}

export default async function CountryPage({
  params,
}: {
  params: Promise<{ country: string }>;
}) {
  const { country } = await params;
  const formattedCountry = formatCountryName(country);

  const { data, error } = await supabase
    .from("program_public_view")
    .select(
      "id,title,slug,country,type,funding_type,deadline,image_url,verification_status,publishing_status,availability_status,deadline_mode,created_at"
    )
    .eq("publishing_status", "published")
    .ilike("country", formattedCountry)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Country page error:", error.message);
  }

  const programs = ((data || []) as Program[]).filter(isPublicProgramListVisible);

  return (
    <main style={{ maxWidth: 1200, margin: "0 auto", padding: "24px 20px 40px" }}>
      <Link
        href="/programs"
        style={{
          display: "inline-block",
          marginBottom: 18,
          textDecoration: "none",
          color: "#0070f3",
          fontWeight: 600,
        }}
      >
        ← Back to programs
      </Link>

      <h1
        style={{
          margin: 0,
          fontSize: 34,
          fontWeight: 800,
          lineHeight: 1.2,
        }}
      >
        Opportunities in {formattedCountry}
      </h1>

      <p style={{ marginTop: 10, color: "#666", lineHeight: 1.7 }}>
        Explore verified scholarships, internships, fellowships, jobs, and more in{" "}
        {formattedCountry}.
      </p>

      <div
        style={{
          marginTop: 8,
          marginBottom: 24,
          color: "#333",
          fontWeight: 600,
        }}
      >
        {programs.length} opportunity{programs.length === 1 ? "" : "ies"} found
      </div>

      {programs.length === 0 ? (
        <div
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 16,
            padding: 24,
            background: "#fafafa",
          }}
        >
          <h2 style={{ marginTop: 0, marginBottom: 10 }}>No opportunities found</h2>
          <p style={{ margin: 0, color: "#666", lineHeight: 1.7 }}>
            There are no verified opportunities for {formattedCountry} yet. Check back
            later or browse all available opportunities on TripDoc.
          </p>
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: 18,
          }}
        >
          {programs.map((program) => (
            <Link
              key={program.id}
              href={program.slug ? `/programs/${program.slug}` : "#"}
              style={{
                display: "block",
                border: "1px solid #e5e7eb",
                borderRadius: 16,
                padding: 18,
                textDecoration: "none",
                color: "#111",
                background: "#fff",
                boxShadow: "0 4px 14px rgba(0,0,0,0.05)",
              }}
            >
              <ProgramImage
                src={program.image_url}
                alt={program.title}
                width={640}
                height={170}
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 360px"
              />

              <div
                style={{
                  fontSize: 20,
                  fontWeight: 700,
                  lineHeight: 1.35,
                  marginBottom: 10,
                }}
              >
                {program.title}
              </div>

              <div style={{ display: "grid", gap: 8, color: "#333", fontSize: 15 }}>
                <div>
                  <strong>Country:</strong> {program.country || "—"}
                </div>
                <div>
                  <strong>Type:</strong> {program.type || "—"}
                </div>
                <div>
                  <strong>Funding:</strong> {program.funding_type || "—"}
                </div>
                <div>
                  <strong>Deadline:</strong> {program.deadline || "—"}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
