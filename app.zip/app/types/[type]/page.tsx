import { supabase } from "../../../lib/supabase";
import { isPublicProgramListVisible } from "../../../lib/opportunityPrograms";
import type { Metadata } from "next";
import Link from "next/link";
import ProgramImage from "../../components/ProgramImage";

type Program = {
  id: string;
  title: string;
  slug: string | null;
  country: string | null;
  type: string | null;
  funding_type: string | null;
  deadline: string | null;
  image_url: string | null;
  verification_status: string | null;
  publishing_status?: string | null;
  availability_status?: string | null;
  deadline_mode?: string | null;
  created_at?: string | null;
};

const SITE_URL = "https://app.tripdoc.net";

function formatTypeName(value: string) {
  return decodeURIComponent(value)
    .replace(/-/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ type: string }>;
}): Promise<Metadata> {
  const { type } = await params;
  const formattedType = formatTypeName(type);

  const title = `${formattedType} Opportunities | TripDoc`;
  const description = `Browse verified ${formattedType.toLowerCase()} opportunities on TripDoc, including scholarships, internships, fellowships, jobs, and more.`;

  return {
    title,
    description,
    alternates: {
      canonical: `${SITE_URL}/types/${type}`,
    },
    openGraph: {
      title,
      description,
      url: `${SITE_URL}/types/${type}`,
      siteName: "TripDoc",
      type: "website",
    },
    twitter: {
      card: "summary",
      title,
      description,
    },
  };
}

export default async function TypePage({
  params,
}: {
  params: Promise<{ type: string }>;
}) {
  const { type } = await params;
  const formattedType = formatTypeName(type);
  const normalizedType = decodeURIComponent(type).toLowerCase().trim();
  const isVolunteerType =
    normalizedType === "volunteer" ||
    normalizedType === "volunteering" ||
    formattedType.toLowerCase().includes("volunteer");

  const { data, error } = await supabase
    .from("program_public_view")
    .select(
      "id,title,slug,country,type,funding_type,deadline,image_url,verification_status,publishing_status,availability_status,deadline_mode,created_at"
    )
    .eq("publishing_status", "published")
    .ilike("type", formattedType)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Type page error:", error.message);
  }

  const programs = ((data || []) as Program[]).filter(isPublicProgramListVisible);

  return (
    <main style={{ maxWidth: 1200, margin: "0 auto", padding: "24px 20px 40px" }}>
      <Link
        href="/programs"
        style={{
          display: "inline-block",
          marginBottom: 18,
          textDecoration: "none",
          color: "#0070f3",
          fontWeight: 600,
        }}
      >
        ← Back to programs
      </Link>

      <h1
        style={{
          margin: 0,
          fontSize: 34,
          fontWeight: 800,
          lineHeight: 1.2,
        }}
      >
        {formattedType} Opportunities
      </h1>

      <p style={{ marginTop: 10, color: "#666", lineHeight: 1.7 }}>
        Explore verified {formattedType.toLowerCase()} opportunities on TripDoc.
      </p>

      <div
        style={{
          marginTop: 8,
          marginBottom: 24,
          color: "#333",
          fontWeight: 600,
        }}
      >
        {programs.length} opportunit{programs.length === 1 ? "y" : "ies"} found
      </div>

      {isVolunteerType ? (
        <div
          style={{
            marginBottom: 24,
            border: "1px solid rgba(41,82,213,0.18)",
            borderRadius: 18,
            padding: "20px 18px",
            background:
              "linear-gradient(135deg, #f8fbff 0%, #eef5ff 100%)",
            boxShadow: "0 10px 28px rgba(41,82,213,0.08)",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 16,
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <div style={{ maxWidth: 720 }}>
              <h2
                style={{
                  margin: "0 0 8px 0",
                  fontSize: 24,
                  lineHeight: 1.2,
                  fontWeight: 800,
                  color: "#10203a",
                }}
              >
                Not sure which volunteer route fits your profile?
              </h2>
              <p style={{ margin: 0, color: "#475569", lineHeight: 1.65 }}>
                Try TripDoc Volunteer Match.
              </p>
            </div>

            <Link
              href="/volunteer-match"
              style={{
                background: "#2952d5",
                color: "#ffffff",
                padding: "12px 16px",
                borderRadius: 10,
                textDecoration: "none",
                fontWeight: 800,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                minHeight: 44,
                boxShadow: "0 8px 20px rgba(41,82,213,0.18)",
              }}
            >
              Check My Match
            </Link>
          </div>
        </div>
      ) : null}

      {programs.length === 0 ? (
        <div
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 16,
            padding: 24,
            background: "#fafafa",
          }}
        >
          <h2 style={{ marginTop: 0, marginBottom: 10 }}>No opportunities found</h2>
          <p style={{ margin: 0, color: "#666", lineHeight: 1.7 }}>
            There are no verified {formattedType.toLowerCase()} opportunities yet.
            Check back later or browse all available opportunities on TripDoc.
          </p>
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap: 18,
          }}
        >
          {programs.map((program) => (
            <Link
              key={program.id}
              href={program.slug ? `/programs/${program.slug}` : "#"}
              style={{
                display: "block",
                border: "1px solid #e5e7eb",
                borderRadius: 16,
                padding: 18,
                textDecoration: "none",
                color: "#111",
                background: "#fff",
                boxShadow: "0 4px 14px rgba(0,0,0,0.05)",
              }}
            >
              <ProgramImage
                src={program.image_url}
                alt={program.title}
                width={640}
                height={170}
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 360px"
              />

              <div
                style={{
                  fontSize: 20,
                  fontWeight: 700,
                  lineHeight: 1.35,
                  marginBottom: 10,
                }}
              >
                {program.title}
              </div>

              <div style={{ display: "grid", gap: 8, color: "#333", fontSize: 15 }}>
                <div>
                  <strong>Country:</strong> {program.country || "—"}
                </div>
                <div>
                  <strong>Type:</strong> {program.type || "—"}
                </div>
                <div>
                  <strong>Funding:</strong> {program.funding_type || "—"}
                </div>
                <div>
                  <strong>Deadline:</strong> {program.deadline || "—"}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
