export const dynamic = "force-dynamic";

import Link from "next/link";
import { supabase } from "../lib/supabase";
import { isPublicProgramListVisible } from "../lib/opportunityPrograms";
import ProgramsClient from "./programs/ProgramsClient";
import HorizontalRow from "./components/HorizontalRow";
import HeroSearch from "./components/HeroSearch";
import ProgramImage from "./components/ProgramImage";
import TrackedProgramLink from "./components/TrackedProgramLink";

type Program = {
  id: string;
  title: string;
  slug: string | null;
  country: string | null;
  type: string | null;
  funding_type: string | null;
  deadline: string | null;
  official_url: string | null;
  image_url: string | null;
  verification_status: string | null;
  publishing_status?: string | null;
  availability_status?: string | null;
  deadline_mode?: string | null;
  created_at?: string | null;
  featured?: boolean | null;
};

type ClickRow = {
  program_id: string | null;
  title?: string | null;
  type?: string | null;
  action?: string | null;
  created_at?: string | null;
};

const quickCardStyle = {
  border: "1px solid #e5e7eb",
  borderRadius: 16,
  padding: "16px 18px",
  textDecoration: "none",
  color: "black",
  background: "#ffffff",
  fontWeight: 700,
  fontSize: 16,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  minHeight: 64,
  minWidth: 220,
  boxShadow: "0 2px 10px rgba(0,0,0,0.05)",
  transition: "all 0.2s ease",
} as const;

const cardStyle = {
  border: "1px solid #e5e7eb",
  padding: 18,
  borderRadius: 14,
  background: "white",
  minWidth: 260,
  boxShadow: "0 2px 10px rgba(0,0,0,0.04)",
  transition: "transform 0.2s ease, box-shadow 0.2s ease",
} as const;

const featuredCardStyle = {
  border: "1px solid #f1ddbf",
  padding: 18,
  borderRadius: 18,
  background: "#ffffff",
  minWidth: 290,
  boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
  transition: "transform 0.2s ease, box-shadow 0.2s ease",
} as const;

function toCountrySlug(country: string) {
  return country.toLowerCase().trim().replace(/\s+/g, "-");
}

function toFundingSlug(funding: string) {
  return funding.toLowerCase().trim().replace(/\s+/g, "-");
}

function isNotExpired(deadline?: string | null) {
  if (!deadline) return true;

  const today = new Date();
  const d = new Date(deadline + "T23:59:59");

  return d.getTime() >= today.getTime();
}

function rankProgramsByClicks(clicks: ClickRow[] = [], actionFilter?: string) {
  const counts = new Map<string, number>();

  for (const row of clicks) {
    if (!row.program_id) continue;
    if (actionFilter && row.action !== actionFilter) continue;

    counts.set(row.program_id, (counts.get(row.program_id) || 0) + 1);
  }

  return [...counts.entries()].sort((a, b) => b[1] - a[1]);
}

function rankProgramsByWeightedClicks(clicks: ClickRow[] = []) {
  const scores = new Map<string, number>();

  for (const row of clicks) {
    if (!row.program_id) continue;

    let weight = 1;
    if (row.action === "apply_now") weight = 3;
    if (row.action === "copy_link") weight = 2;
    if (row.action === "open_detail") weight = 1;

    scores.set(row.program_id, (scores.get(row.program_id) || 0) + weight);
  }

  return [...scores.entries()].sort((a, b) => b[1] - a[1]);
}

function pickProgramsByRank(
  programs: Program[],
  rankedEntries: [string, number][],
  limit = 6,
  excludeIds = new Set<string>()
) {
  const byId = new Map(programs.map((p) => [p.id, p]));
  const results: Program[] = [];

  for (const [programId] of rankedEntries) {
    const program = byId.get(programId);
    if (!program) continue;
    if (excludeIds.has(program.id)) continue;
    if (!program.slug) continue;
    if (!isPublicProgramListVisible(program)) continue;

    results.push(program);

    if (results.length >= limit) break;
  }

  return results;
}

function getMetricMap(entries: [string, number][]) {
  return new Map(entries);
}

function formatDeadline(deadline?: string | null) {
  if (!deadline) return "No deadline";

  const date = new Date(deadline);
  if (Number.isNaN(date.getTime())) return deadline;

  return new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
}

function getCountryEmoji(country?: string | null) {
  const value = (country || "").trim().toLowerCase();

  const map: Record<string, string> = {
    germany: "🇩🇪",
    canada: "🇨🇦",
    netherlands: "🇳🇱",
    australia: "🇦🇺",
    uk: "🇬🇧",
    "united kingdom": "🇬🇧",
    usa: "🇺🇸",
    "united states": "🇺🇸",
    ireland: "🇮🇪",
    france: "🇫🇷",
    italy: "🇮🇹",
    spain: "🇪🇸",
    switzerland: "🇨🇭",
    belgium: "🇧🇪",
    austria: "🇦🇹",
    sweden: "🇸🇪",
    norway: "🇳🇴",
    finland: "🇫🇮",
    denmark: "🇩🇰",
    japan: "🇯🇵",
    china: "🇨🇳",
    singapore: "🇸🇬",
    malaysia: "🇲🇾",
    poland: "🇵🇱",
    romania: "🇷🇴",
    hungary: "🇭🇺",
    portugal: "🇵🇹",
    "new zealand": "🇳🇿",
    india: "🇮🇳",
    "south korea": "🇰🇷",
  };

  return map[value] || "🌍";
}

function ProgramCard({
  program,
  badge,
  badgeStyle,
  meta,
  featured = false,
}: {
  program: Program;
  badge?: string;
  badgeStyle?: Record<string, string | number>;
  meta?: string;
  featured?: boolean;
}) {
  if (!program.slug) return null;

  return (
    <TrackedProgramLink
      href={`/programs/${program.slug}`}
      programId={program.id}
      className="horizontal-card"
      style={{
        ...(featured ? featuredCardStyle : cardStyle),
        display: "block",
        textDecoration: "none",
        color: "inherit",
      }}
    >
      {program.image_url && (
        <ProgramImage
          src={program.image_url}
          alt={program.title}
          width={640}
          height={featured ? 170 : 140}
          sizes={featured ? "(max-width: 768px) 100vw, 360px" : "(max-width: 768px) 100vw, 320px"}
          borderRadius={10}
          marginBottom={12}
        />
      )}

      {badge && (
        <div
          style={{
            display: "inline-block",
            marginBottom: 10,
            padding: "6px 10px",
            borderRadius: 999,
            fontWeight: 700,
            fontSize: 13,
            ...badgeStyle,
          }}
        >
          {badge}
        </div>
      )}

      <div
        style={{
          fontSize: featured ? 20 : 18,
          fontWeight: 700,
          color: "black",
          lineHeight: 1.4,
        }}
      >
        {program.title}
      </div>

      <div
        style={{
          marginTop: 8,
          fontSize: 14,
          color: "#555",
          lineHeight: 1.5,
        }}
      >
        {meta || `${program.country || "—"} • ${program.funding_type || "—"}`}
      </div>

      {featured && (
        <div
          style={{
            marginTop: 12,
            display: "flex",
            gap: 8,
            flexWrap: "wrap",
            fontSize: 13,
            fontWeight: 600,
            color: "#6b7280",
          }}
        >
          {program.country && <span>🌍 {program.country}</span>}
          {program.type && <span>📚 {program.type}</span>}
          {program.deadline && <span>⏰ {formatDeadline(program.deadline)}</span>}
        </div>
      )}
    </TrackedProgramLink>
  );
}

export default async function Home() {
  const now = new Date();

  const sevenDaysAgo = new Date(now);
  sevenDaysAgo.setDate(now.getDate() - 7);

  const thirtyDaysAgo = new Date(now);
  thirtyDaysAgo.setDate(now.getDate() - 30);

  const { data, error } = await supabase
    .from("program_public_view")
    .select(
      "id,title,slug,type,country,funding_type,deadline,official_url,image_url,verification_status,publishing_status,availability_status,deadline_mode,created_at,featured"
    )
    .eq("publishing_status", "published")
    .order("created_at", { ascending: false });

  if (error) {
    return (
      <pre style={{ padding: 24, whiteSpace: "pre-wrap" }}>
        {JSON.stringify(error, null, 2)}
      </pre>
    );
  }

  const programs = ((data || []) as Program[]).filter((p) => {
    const cleanTitle = p.title?.trim().toLowerCase();

    return (
      !!p.id &&
      !!p.slug &&
      !!p.title &&
      cleanTitle !== "featured" &&
      cleanTitle !== "test" &&
      cleanTitle !== "draft"
    );
  });

  const verifiedActivePrograms = programs.filter(isPublicProgramListVisible);

  const totalVerifiedPrograms = verifiedActivePrograms.length;

  const totalActivePrograms = verifiedActivePrograms.length;

  const uniqueCountries = new Set(
    programs
      .map((p) => p.country?.trim())
      .filter((value): value is string => Boolean(value))
  ).size;

  const homepageCountries = Array.from(
    new Set(
      verifiedActivePrograms
        .map((p) => p.country?.trim())
        .filter((value): value is string => Boolean(value))
    )
  )
    .sort((a, b) => a.localeCompare(b))
    .slice(0, 8);

  const homepageFunding = Array.from(
    new Set(
      verifiedActivePrograms
        .map((p) => p.funding_type?.trim())
        .filter((value): value is string => Boolean(value))
    )
  )
    .sort((a, b) => a.localeCompare(b))
    .slice(0, 8);

  const { data: clickData } = await supabase
    .from("clicks")
    .select("program_id,title,type,action,created_at")
    .order("created_at", { ascending: false })
    .limit(500);

  const { data: clickData7d } = await supabase
    .from("clicks")
    .select("program_id,title,type,action,created_at")
    .gte("created_at", sevenDaysAgo.toISOString())
    .order("created_at", { ascending: false })
    .limit(500);

  const { data: clickData30d } = await supabase
    .from("clicks")
    .select("program_id,title,type,action,created_at")
    .gte("created_at", thirtyDaysAgo.toISOString())
    .order("created_at", { ascending: false })
    .limit(1000);

  const clicks = (clickData || []) as ClickRow[];
  const clicks7d = (clickData7d || []) as ClickRow[];
  const clicks30d = (clickData30d || []) as ClickRow[];

  const overallClickRanking = rankProgramsByClicks(clicks);
  const weightedTrending7dRanking = rankProgramsByWeightedClicks(clicks7d);
  const weightedTrending30dRanking = rankProgramsByWeightedClicks(clicks30d);
  const mostAppliedRanking = rankProgramsByClicks(clicks7d, "apply_now");
  const mostSharedRanking = rankProgramsByClicks(clicks7d, "copy_link");

  const clickCountMap = getMetricMap(overallClickRanking);
  const trending7dMap = getMetricMap(weightedTrending7dRanking);
  const trending30dMap = getMetricMap(weightedTrending30dRanking);
  const mostAppliedMap = getMetricMap(mostAppliedRanking);
  const mostSharedMap = getMetricMap(mostSharedRanking);

  const manuallyFeaturedPrograms = verifiedActivePrograms.filter((p) => p.featured);

  const fallbackFeaturedPrograms = [...verifiedActivePrograms].sort((a, b) => {
    const aTime = a.created_at ? new Date(a.created_at).getTime() : 0;
    const bTime = b.created_at ? new Date(b.created_at).getTime() : 0;
    return bTime - aTime;
  });

  const featuredPrograms =
    manuallyFeaturedPrograms.length > 0
      ? manuallyFeaturedPrograms.slice(0, 6)
      : fallbackFeaturedPrograms.slice(0, 6);

  const featuredIds = new Set(featuredPrograms.map((p) => p.id));

  const closingSoon = verifiedActivePrograms
    .filter((p) => {
      if (!p.deadline) return false;
      if (featuredIds.has(p.id)) return false;

      const deadline = new Date(p.deadline + "T23:59:59");
      const today = new Date();

      const diff =
        (deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24);

      return diff <= 7 && diff >= 0;
    })
    .slice(0, 6);

  const closingSoonIds = new Set(closingSoon.map((p) => p.id));

  const trendingFromClicks = pickProgramsByRank(
    verifiedActivePrograms,
    overallClickRanking,
    6,
    new Set([...featuredIds, ...closingSoonIds])
  );

  const trendingFromClicksIds = new Set(trendingFromClicks.map((p) => p.id));

  const newlyAdded = verifiedActivePrograms
    .filter(
      (p) =>
        !featuredIds.has(p.id) &&
        !closingSoonIds.has(p.id) &&
        !trendingFromClicksIds.has(p.id)
    )
    .slice(0, 4);

  const newlyAddedIds = new Set(newlyAdded.map((p) => p.id));

  const excludedForAnalytics = new Set<string>([
    ...featuredIds,
    ...closingSoonIds,
    ...newlyAddedIds,
    ...trendingFromClicksIds,
  ]);

  const trendingThisWeek = pickProgramsByRank(
    verifiedActivePrograms,
    weightedTrending7dRanking,
    6,
    excludedForAnalytics
  );

  const trendingThisMonth = pickProgramsByRank(
    verifiedActivePrograms,
    weightedTrending30dRanking,
    6,
    excludedForAnalytics
  );

  const mostApplied = pickProgramsByRank(
    verifiedActivePrograms,
    mostAppliedRanking,
    6,
    excludedForAnalytics
  );

  const mostShared = pickProgramsByRank(
    verifiedActivePrograms,
    mostSharedRanking,
    6,
    excludedForAnalytics
  );

  const popularPrograms = verifiedActivePrograms
    .filter((p) => !featuredIds.has(p.id) && !closingSoonIds.has(p.id))
    .slice(0, 6);
  const homepageOpportunityPreview = verifiedActivePrograms.slice(0, 18);

  return (
    <>
      <div
        style={{
          width: "100%",
          background: "linear-gradient(135deg, #17307a 0%, #2952d5 100%)",
          marginBottom: 0,
          paddingTop: 24,
          paddingBottom: 30,
        }}
      >
        <div
          style={{
            maxWidth: 1100,
            margin: "0 auto",
            padding: "0 20px",
            textAlign: "center",
            color: "white",
          }}
        >
          <h1
            style={{
              fontSize: "clamp(34px, 5vw, 58px)",
              fontWeight: 800,
              margin: "0 auto 14px",
              lineHeight: 1.08,
              maxWidth: 900,
              letterSpacing: "-0.02em",
            }}
          >
            Discover Verified Global Opportunities
          </h1>

          <p
            style={{
              fontSize: 18,
              color: "rgba(255,255,255,0.92)",
              maxWidth: 760,
              margin: "0 auto 22px",
              lineHeight: 1.55,
              fontWeight: 500,
            }}
          >
            Scholarships, internships, fellowships, and research programs —
            all verified with official links to help you apply with confidence.
          </p>

          <div
            style={{
              display: "flex",
              gap: 14,
              justifyContent: "center",
              flexWrap: "wrap",
              marginBottom: 28,
            }}
          >
            <Link
              href="/types/scholarship"
              style={{
                background: "#ffffff",
                color: "#2952d5",
                padding: "14px 24px",
                borderRadius: 10,
                textDecoration: "none",
                fontWeight: 700,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                minWidth: 220,
                border: "1px solid rgba(255,255,255,0.2)",
                boxShadow: "0 6px 18px rgba(0,0,0,0.08)",
              }}
            >
              🎓 Explore Scholarships
            </Link>

            <Link
              href="/types/internship"
              style={{
                border: "1px solid rgba(255,255,255,0.65)",
                padding: "14px 24px",
                borderRadius: 10,
                textDecoration: "none",
                fontWeight: 700,
                color: "white",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                minWidth: 220,
                background: "rgba(255,255,255,0.04)",
              }}
            >
              💼 Explore Internships
            </Link>
          </div>

          <div style={{ maxWidth: 760, margin: "0 auto 24px" }}>
            <HeroSearch />
          </div>

          <div
            style={{
              display: "flex",
              gap: 12,
              flexWrap: "wrap",
              justifyContent: "center",
              marginTop: 14,
              marginBottom: 18,
            }}
          >
            {[
              `🌍 ${uniqueCountries}+ Countries`,
              `🎓 ${totalActivePrograms}+ Active Opportunities`,
              `✅ ${totalVerifiedPrograms}+ Verified Listings`,
              "⚡ Updated Regularly",
            ].map((item) => (
              <div
                key={item}
                style={{
                  border: "1px solid rgba(255,255,255,0.12)",
                  padding: "12px 18px",
                  borderRadius: 10,
                  background: "rgba(255,255,255,0.08)",
                  fontWeight: 700,
                  fontSize: 15,
                  color: "#ffffff",
                  minWidth: 210,
                  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.06)",
                }}
              >
                {item}
              </div>
            ))}
          </div>

          <div
            style={{
              display: "flex",
              gap: 28,
              flexWrap: "wrap",
              justifyContent: "center",
              marginTop: 8,
              color: "rgba(255,255,255,0.95)",
              fontSize: 15,
              fontWeight: 600,
              paddingBottom: 8,
            }}
          >
            <span>✅ Verified from official sources</span>
            <span>🌍 Global opportunities</span>
            <span>🔎 Easy search and filters</span>
            <span>🚫 No agents, no hidden fees</span>
          </div>
        </div>
      </div>

      <main style={{ maxWidth: 1100, margin: "0 auto", padding: "20px 16px 48px" }}>
        <div
          style={{
            marginTop: 0,
            marginBottom: 22,
            border: "1px solid #e5e7eb",
            borderRadius: 18,
            padding: "22px 22px 16px",
            background: "#ffffff",
            boxShadow: "0 1px 2px rgba(0,0,0,0.03)",
          }}
        >
          <h2
            style={{
              margin: "0 0 10px 0",
              fontSize: 26,
              fontWeight: 800,
            }}
          >
            Why Trust TripDoc?
          </h2>

          <p
            style={{
              margin: "0 0 18px 0",
              color: "#666",
              maxWidth: 760,
              lineHeight: 1.6,
            }}
          >
            We focus on verified global opportunities and present them in a simple,
            searchable format so students and professionals can find real options faster.
          </p>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
              gap: 14,
            }}
          >
            {[
              {
                title: "✅ Verified sources",
                text: "We prioritize opportunities with traceable official links and clear details.",
              },
              {
                title: "🌍 Global opportunities",
                text: "Scholarships, internships, research and fellowships across multiple countries.",
              },
              {
                title: "⚡ Updated regularly",
                text: "New programs are added frequently so visitors can keep discovering fresh options.",
              },
              {
                title: "🔎 Easy to search",
                text: "Use smart search, filters and landing pages to find the right match quickly.",
              },
            ].map((item) => (
              <div
                key={item.title}
                style={{
                  border: "1px solid #edf0f4",
                  borderRadius: 14,
                  padding: 16,
                  background: "#f8fafc",
                }}
              >
                <div style={{ fontWeight: 700, marginBottom: 8 }}>{item.title}</div>
                <div style={{ color: "#555", fontSize: 14, lineHeight: 1.6 }}>
                  {item.text}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div
          style={{
            marginTop: 0,
            marginBottom: 28,
            border: "1px solid rgba(41,82,213,0.18)",
            borderRadius: 20,
            padding: "28px 24px",
            background:
              "linear-gradient(135deg, #f8fbff 0%, #eef5ff 100%)",
            boxShadow: "0 14px 35px rgba(41,82,213,0.1)",
            color: "#10203a",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 22,
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <div style={{ maxWidth: 760 }}>
              <div
                style={{
                  display: "inline-block",
                  marginBottom: 10,
                  padding: "6px 12px",
                  borderRadius: 999,
                  background: "#dbeafe",
                  border: "1px solid #bfdbfe",
                  color: "#17307a",
                  fontWeight: 800,
                  fontSize: 13,
                }}
              >
                Volunteer Match
              </div>

              <h2 style={{ margin: "0 0 10px 0", fontSize: 30, fontWeight: 800 }}>
                Not sure which Germany volunteer route fits you?
              </h2>

              <p
                style={{
                  color: "#475569",
                  margin: 0,
                  lineHeight: 1.65,
                  fontSize: 16,
                }}
              >
                Use TripDoc Volunteer Match to compare your profile with verified
                routes such as weltwärts, BFD, FSJ, FÖJ and selected SCI
                programmes.
              </p>
            </div>

            <Link
              href="/volunteer-match"
              style={{
                background: "#2952d5",
                color: "#ffffff",
                padding: "13px 18px",
                borderRadius: 10,
                textDecoration: "none",
                fontWeight: 800,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                minHeight: 46,
                minWidth: 220,
                boxShadow: "0 8px 22px rgba(41,82,213,0.18)",
              }}
            >
              Check My Volunteer Routes
            </Link>
          </div>
        </div>

        <div
          style={{
            marginTop: 0,
            marginBottom: 28,
            border: "1px solid rgba(41,82,213,0.22)",
            borderRadius: 20,
            padding: "28px 24px",
            background:
              "linear-gradient(135deg, #17307a 0%, #2952d5 72%, #3b82f6 100%)",
            boxShadow: "0 14px 35px rgba(23,48,122,0.16)",
            color: "white",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 22,
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <div style={{ maxWidth: 720 }}>
              <div
                style={{
                  display: "inline-block",
                  marginBottom: 10,
                  padding: "6px 12px",
                  borderRadius: 999,
                  background: "rgba(255,255,255,0.14)",
                  border: "1px solid rgba(255,255,255,0.22)",
                  color: "rgba(255,255,255,0.94)",
                  fontWeight: 800,
                  fontSize: 13,
                }}
              >
                Career discovery
              </div>

              <h2 style={{ margin: "0 0 10px 0", fontSize: 30, fontWeight: 800 }}>
                2026 Global Hiring Companies by Country
              </h2>

              <p
                style={{
                  color: "rgba(255,255,255,0.9)",
                  margin: 0,
                  lineHeight: 1.65,
                  fontSize: 16,
                }}
              >
                Browse verified company career pages by country, industry, visa
                sponsorship signals, relocation support, and graduate programs.
              </p>
            </div>

            <Link
              href="/hiring-companies"
              style={{
                background: "#ffffff",
                color: "#2952d5",
                padding: "13px 18px",
                borderRadius: 10,
                textDecoration: "none",
                fontWeight: 800,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                minHeight: 46,
                minWidth: 210,
                boxShadow: "0 8px 22px rgba(0,0,0,0.12)",
              }}
            >
              Explore Hiring Companies
            </Link>
          </div>
        </div>

        <div
          style={{
            marginTop: 0,
            marginBottom: 28,
            border: "1px solid #f1ddbf",
            borderRadius: 20,
            padding: "18px 16px 20px",
            background: "#fffdf9",
            boxShadow: "0 1px 2px rgba(0,0,0,0.02)",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 16,
              alignItems: "flex-end",
              flexWrap: "wrap",
              marginBottom: 18,
            }}
          >
            <div>
              <div
                style={{
                  display: "inline-block",
                  marginBottom: 10,
                  padding: "6px 12px",
                  borderRadius: 999,
                  background: "#fff1cc",
                  color: "#c77800",
                  fontWeight: 800,
                  fontSize: 13,
                }}
              >
                ⭐ Editor’s Picks
              </div>

              <h2 style={{ margin: "0 0 8px 0", fontSize: 30, fontWeight: 800 }}>
                Featured Opportunities
              </h2>

              <p style={{ color: "#666", margin: 0, maxWidth: 760, lineHeight: 1.6 }}>
                Hand-picked and priority opportunities selected by TripDoc for faster
                discovery.
              </p>
            </div>

            <a
              href="#all-opportunities"
              style={{
                textDecoration: "none",
                fontWeight: 700,
                color: "#c77800",
                padding: "10px 14px",
                borderRadius: 10,
                background: "#fff",
                border: "1px solid #f1ddbf",
              }}
            >
              Browse all →
            </a>
          </div>

          {featuredPrograms.length > 0 ? (
            <HorizontalRow>
              {featuredPrograms.map((p) => (
                <ProgramCard
                  key={p.id}
                  program={p}
                  featured
                  badge="⭐ Featured"
                  badgeStyle={{
                    background: "#fff1cc",
                    color: "#c77800",
                  }}
                  meta={`${p.country || "—"} • ${p.funding_type || "—"}`}
                />
              ))}
            </HorizontalRow>
          ) : (
            <div
              style={{
                border: "1px dashed #e6d7a2",
                borderRadius: 16,
                padding: "22px 18px",
                background: "#fffdf7",
                color: "#6b7280",
              }}
            >
              <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 8 }}>
                No featured opportunities yet
              </div>
              <div style={{ lineHeight: 1.6, marginBottom: 14 }}>
                Use the admin dashboard to mark strong opportunities as featured, and
                they will appear here automatically.
              </div>
              <a
                href="#all-opportunities"
                style={{
                  display: "inline-block",
                  textDecoration: "none",
                  fontWeight: 700,
                  color: "#8a5a00",
                  padding: "10px 14px",
                  borderRadius: 10,
                  background: "#fff",
                  border: "1px solid #f3e7b3",
                }}
              >
                Explore all opportunities
              </a>
            </div>
          )}
        </div>

        <div
          style={{
            marginTop: 60,
            paddingBottom: 30,
            borderBottom: "1px solid #f1f1f1",
          }}
        >
          <h2
            style={{
              fontSize: 30,
              fontWeight: 800,
              marginBottom: 6,
            }}
          >
            Browse by Type
          </h2>

          <p
            style={{
              color: "#666",
              marginBottom: 22,
              fontSize: 16,
            }}
          >
            Explore opportunities by type.
          </p>

          <HorizontalRow>
            <Link href="/types/scholarship" style={quickCardStyle} className="horizontal-card">
              🎓 Scholarships
            </Link>

            <Link href="/types/internship" style={quickCardStyle} className="horizontal-card">
              💼 Internships
            </Link>

            <Link href="/types/research" style={quickCardStyle} className="horizontal-card">
              🔬 Research
            </Link>

            <Link href="/types/fellowship" style={quickCardStyle} className="horizontal-card">
              🌍 Fellowships
            </Link>
          </HorizontalRow>
        </div>

        <div
          style={{
            marginTop: 60,
            paddingBottom: 30,
            borderBottom: "1px solid #f1f1f1",
          }}
        >
          <h2
            style={{
              fontSize: 30,
              fontWeight: 800,
              marginBottom: 6,
            }}
          >
            Browse by Country
          </h2>

          <p
            style={{
              color: "#666",
              marginBottom: 22,
              fontSize: 16,
            }}
          >
            Explore opportunities by destination country.
          </p>

          <HorizontalRow>
            {homepageCountries.length > 0 ? (
              homepageCountries.map((country) => (
                <Link
                  key={country}
                  href={`/countries/${toCountrySlug(country)}`}
                  style={quickCardStyle}
                  className="horizontal-card"
                >
                  {getCountryEmoji(country)} {country}
                </Link>
              ))
            ) : (
              <div
                style={{
                  ...quickCardStyle,
                  minWidth: 260,
                  color: "#666",
                }}
              >
                🌍 Countries will appear here automatically
              </div>
            )}
          </HorizontalRow>
        </div>

        <div
          style={{
            marginTop: 60,
            paddingBottom: 30,
            borderBottom: "1px solid #f1f1f1",
          }}
        >
          <h2
            style={{
              fontSize: 30,
              fontWeight: 800,
              marginBottom: 6,
            }}
          >
            Browse by Funding
          </h2>

          <p
            style={{
              color: "#666",
              marginBottom: 22,
              fontSize: 16,
            }}
          >
            Explore opportunities by funding type.
          </p>

          <HorizontalRow>
            {homepageFunding.length > 0 ? (
              homepageFunding.map((funding) => (
                <Link
                  key={funding}
                  href={`/funding/${toFundingSlug(funding)}`}
                  style={quickCardStyle}
                  className="horizontal-card"
                >
                  💰 {funding}
                </Link>
              ))
            ) : (
              <div
                style={{
                  ...quickCardStyle,
                  minWidth: 260,
                  color: "#666",
                }}
              >
                💰 Funding types will appear here automatically
              </div>
            )}
          </HorizontalRow>
        </div>

        <div style={{ marginTop: 56 }}>
          <h2 style={{ marginBottom: 10, fontSize: 28, fontWeight: 700 }}>
            🔥 Closing Soon
          </h2>
          <p style={{ color: "#666", marginBottom: 20 }}>
            Opportunities with deadlines approaching within the next 7 days.
          </p>

          {closingSoon.length === 0 ? (
            <p>No urgent deadlines right now.</p>
          ) : (
            <HorizontalRow>
              {closingSoon.map((p) => (
                <ProgramCard
                  key={p.id}
                  program={p}
                  badge="⏰ Closing Soon"
                  badgeStyle={{
                    background: "#fff1db",
                    color: "#a05a00",
                  }}
                  meta={`Deadline: ${formatDeadline(p.deadline)}`}
                />
              ))}
            </HorizontalRow>
          )}
        </div>

        {trendingFromClicks.length > 0 && (
          <div style={{ marginTop: 56 }}>
            <h2 style={{ marginBottom: 10, fontSize: 28, fontWeight: 700 }}>
              📈 Trending by Users
            </h2>
            <p style={{ color: "#666", marginBottom: 20 }}>
              Opportunities getting the most interest from recent visitors on TripDoc.
            </p>

            <HorizontalRow>
              {trendingFromClicks.map((p) => (
                <ProgramCard
                  key={p.id}
                  program={p}
                  badge={`🔥 ${clickCountMap.get(p.id) || 0} clicks`}
                  badgeStyle={{
                    background: "#eef4ff",
                    color: "#1d4ed8",
                  }}
                />
              ))}
            </HorizontalRow>
          </div>
        )}

        {trendingThisWeek.length > 0 && (
          <div style={{ marginTop: 56 }}>
            <h2 style={{ marginBottom: 10, fontSize: 28, fontWeight: 700 }}>
              📊 Trending This Week
            </h2>
            <p style={{ color: "#666", marginBottom: 20 }}>
              Opportunities with the strongest user activity in the last 7 days.
            </p>

            <HorizontalRow>
              {trendingThisWeek.map((p) => (
                <ProgramCard
                  key={p.id}
                  program={p}
                  badge={`⚡ Score ${trending7dMap.get(p.id) || 0}`}
                  badgeStyle={{
                    background: "#ecfeff",
                    color: "#0f766e",
                  }}
                />
              ))}
            </HorizontalRow>
          </div>
        )}

        {trendingThisMonth.length > 0 && (
          <div style={{ marginTop: 56 }}>
            <h2 style={{ marginBottom: 10, fontSize: 28, fontWeight: 700 }}>
              🗓️ Trending This Month
            </h2>
            <p style={{ color: "#666", marginBottom: 20 }}>
              Opportunities that kept attracting attention in the last 30 days.
            </p>

            <HorizontalRow>
              {trendingThisMonth.map((p) => (
                <ProgramCard
                  key={p.id}
                  program={p}
                  badge={`📈 Score ${trending30dMap.get(p.id) || 0}`}
                  badgeStyle={{
                    background: "#f3f0ff",
                    color: "#6d28d9",
                  }}
                />
              ))}
            </HorizontalRow>
          </div>
        )}

        {mostApplied.length > 0 && (
          <div style={{ marginTop: 56 }}>
            <h2 style={{ marginBottom: 10, fontSize: 28, fontWeight: 700 }}>
              📝 Most Applied
            </h2>
            <p style={{ color: "#666", marginBottom: 20 }}>
              Opportunities users clicked Apply Now on the most in the last 7 days.
            </p>

            <HorizontalRow>
              {mostApplied.map((p) => (
                <ProgramCard
                  key={p.id}
                  program={p}
                  badge={`🚀 ${mostAppliedMap.get(p.id) || 0} apply clicks`}
                  badgeStyle={{
                    background: "#effdf5",
                    color: "#15803d",
                  }}
                />
              ))}
            </HorizontalRow>
          </div>
        )}

        {mostShared.length > 0 && (
          <div style={{ marginTop: 56 }}>
            <h2 style={{ marginBottom: 10, fontSize: 28, fontWeight: 700 }}>
              🔗 Most Shared
            </h2>
            <p style={{ color: "#666", marginBottom: 20 }}>
              Opportunities users copied and shared the most in the last 7 days.
            </p>

            <HorizontalRow>
              {mostShared.map((p) => (
                <ProgramCard
                  key={p.id}
                  program={p}
                  badge={`📎 ${mostSharedMap.get(p.id) || 0} shares`}
                  badgeStyle={{
                    background: "#fff7ed",
                    color: "#c2410c",
                  }}
                />
              ))}
            </HorizontalRow>
          </div>
        )}

        <div style={{ marginTop: 56 }}>
          <h2 style={{ marginBottom: 10, fontSize: 28, fontWeight: 700 }}>
            🔥 Popular Opportunities
          </h2>

          <p style={{ color: "#666", marginBottom: 20 }}>
            Verified programs many students are currently exploring.
          </p>

          <HorizontalRow>
            {popularPrograms.map((p) => (
              <ProgramCard key={p.id} program={p} />
            ))}
          </HorizontalRow>
        </div>

        {newlyAdded.length > 0 && (
          <div style={{ marginTop: 56 }}>
            <h2 style={{ marginBottom: 10, fontSize: 28, fontWeight: 700 }}>
              🆕 Newly Added Opportunities
            </h2>
            <p style={{ color: "#666", marginBottom: 20 }}>
              Recently added verified programs on TripDoc.
            </p>

            <HorizontalRow>
              {newlyAdded.map((p) => (
                <ProgramCard key={p.id} program={p} />
              ))}
            </HorizontalRow>
          </div>
        )}

        <div
          style={{
            marginTop: 72,
            marginBottom: 20,
            border: "1px solid #e5e7eb",
            borderRadius: 20,
            padding: "28px 24px",
            background: "linear-gradient(180deg, #f8fbff 0%, #ffffff 100%)",
            boxShadow: "0 6px 20px rgba(0,0,0,0.04)",
          }}
        >
          <h2 style={{ margin: "0 0 10px 0", fontSize: 28, fontWeight: 800 }}>
            Ready to explore more?
          </h2>
          <p style={{ color: "#666", margin: "0 0 18px 0", lineHeight: 1.6, maxWidth: 760 }}>
            Use TripDoc to explore verified opportunities by country, type, funding,
            deadline, and popularity — all in one place.
          </p>

          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <a
              href="#all-opportunities"
              style={{
                background: "#0070f3",
                color: "white",
                padding: "12px 18px",
                borderRadius: 10,
                textDecoration: "none",
                fontWeight: 700,
              }}
            >
              Explore All Opportunities
            </a>

            <Link
              href="/programs"
              style={{
                border: "1px solid #ddd",
                padding: "12px 18px",
                borderRadius: 10,
                textDecoration: "none",
                fontWeight: 700,
                color: "#333",
                background: "white",
              }}
            >
              Open Programs Page
            </Link>
          </div>
        </div>

        <div id="all-opportunities" style={{ marginTop: 88 }}>
          <div style={{ marginBottom: 20 }}>
            <h2 style={{ marginBottom: 10, fontSize: 30, fontWeight: 800 }}>
              Explore All Opportunities
            </h2>

            <p style={{ color: "#666", margin: 0, maxWidth: 760, fontSize: 17 }}>
              Search and filter verified scholarships, internships, fellowships, and
              research programs from around the world.
            </p>
          </div>

          <ProgramsClient
            initialPrograms={homepageOpportunityPreview}
            totalPrograms={homepageOpportunityPreview.length}
          />

          {verifiedActivePrograms.length > homepageOpportunityPreview.length && (
            <div style={{ marginTop: 24, textAlign: "center" }}>
              <Link
                href="/programs"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  borderRadius: 999,
                  padding: "12px 18px",
                  background: "#0b5cff",
                  color: "white",
                  textDecoration: "none",
                  fontWeight: 800,
                  boxShadow: "0 10px 24px rgba(11,92,255,0.18)",
                }}
              >
                View all opportunities
              </Link>
            </div>
          )}
        </div>
      </main>
    </>
  );
}
